Gerenciamento de estoque de cerveja, API nível expert.







Segui exatamente o modelo ensinado afim de evitar erros no projeto. Em geral gosto de fazer meus projetos mais com a minha cara.
